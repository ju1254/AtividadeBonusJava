//package main;
//import management.Museu;
import modelo.ObraDeArte;
import java.util.List;
import java.util.Scanner;

public class CadastroDeObra {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ObrasNoSistema ObrasNoSistema = new ObrasNoSistema();
        boolean continuar = true;

        while (continuar) {
            System.out.println("---MUSEUM---");
            System.out.println("Escolha uma opção:");
            System.out.println("1. Cadastrar nova obra de arte");
            System.out.println("2. Buscar obra de arte por título");
            System.out.println("3. Listar todas as obras de arte");
            System.out.println("4. Sair");
            int op = scanner.nextInt();
            scanner.nextLine(); 

            switch (op) {
                case 1:
                    System.out.println("Cadastro de Obra de Arte");

                    String titulo, artista, tipo, localizacao;
                    int anoDeCriacao;

                    do {
                        System.out.print("Título: ");
                        titulo = scanner.nextLine().trim();
                        if (titulo.isEmpty()) {
                            System.out.println("Título não pode ser vazio.");
                        }
                    } while (titulo.isEmpty());

                    do {
                        System.out.print("Artista: ");
                        artista = scanner.nextLine().trim();
                        if (artista.isEmpty()) {
                            System.out.println("Artista não pode ser vazio.");
                        }
                    } while (artista.isEmpty());

                    while (true) {
                        System.out.print("Ano de Criação: ");
                        String anoStr = scanner.nextLine().trim();
                        try {
                            anoDeCriacao = Integer.parseInt(anoStr);
                            if (anoDeCriacao > 0) {
                                break;
                            } else {
                                System.out.println("Ano deve ser maior que zero.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Ano deve ser um número válido.");
                        }
                    }

                    do {
                        System.out.print("Tipo de Obra (pintura, escultura, etc.): ");
                        tipo = scanner.nextLine().trim();
                        if (tipo.isEmpty()) {
                            System.out.println("Tipo não pode ser vazio.");
                        }
                    } while (tipo.isEmpty());

                    do {
                        System.out.print("Localização: ");
                        localizacao = scanner.nextLine().trim();
                        if (localizacao.isEmpty()) {
                            System.out.println("Localização não pode ser vazia.");
                        }
                    } while (localizacao.isEmpty());

                    ObraSDeArte novaObra = new ObraSDeArte(titulo, artista, anoDeCriacao, tipo, localizacao);
                    ObrasNoSistema.adicionarObra(novaObra);
                    break;

                case 2:
                    System.out.print("Buscar pelo Título: ");
                    String tituloBusca = scanner.nextLine().trim();
                    List<ObrasDeArte> obrasEncontradas = museu.buscarObraPorTitulo(tituloBusca);
                    if (obrasEncontradas.isEmpty()) {
                        System.out.println("Nenhuma obra encontrada com o título: " + tituloBusca);
                    } else {
                        System.out.println("Obras encontradas:");
                        for (ObrasDeArte obra : obrasEncontradas) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 3:
                    List<ObrasDeArte> todasAsObras = museu.listarTodasAsObras();
                    if (todasAsObras.isEmpty()) {
                        System.out.println("Nenhuma obra cadastrada.");
                    } else {
                        System.out.println("Todas as obras cadastradas:");
                        for (ObrasDeArte obra : todasAsObras) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 4:
                    continuar = false;
                    break;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }

        scanner.close();
    }
}

