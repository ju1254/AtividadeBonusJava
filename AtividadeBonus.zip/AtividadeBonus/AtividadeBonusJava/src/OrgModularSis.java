package entrada;
import modelo.ObraDeArte;
import java.util.Scanner;

public class OrgModularSis {
    public static ObrasDeArte lerDadosObraDeArte(Scanner scanner) {
        String titulo, artista, tipo, localizacao;
        int anoDeCriacao;

        do {
            System.out.print("Título: ");
            titulo = scanner.nextLine().trim();
            if (titulo.isEmpty()) {
                System.out.println("Título não pode ser vazio.");
            }
        } while (titulo.isEmpty());

        do {
            System.out.print("Artista: ");
            artista = scanner.nextLine().trim();
            if (artista.isEmpty()) {
                System.out.println("Artista não pode ser vazio.");
            }
        } while (artista.isEmpty());

        while (true) {
            System.out.print("Ano de Criação: ");
            String anoStr = scanner.nextLine().trim();
            try {
                anoDeCriacao = Integer.parseInt(anoStr);
                if (anoDeCriacao > 0) {
                    break;
                } else {
                    System.out.println("Ano deve ser maior que zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Ano deve ser um número válido.");
            }
        }

        do {
            System.out.print("Tipo de Obra (pintura, escultura, etc.): ");
            tipo = scanner.nextLine().trim();
            if (tipo.isEmpty()) {
                System.out.println("Tipo não pode ser vazio.");
            }
        } while (tipo.isEmpty());

        do {
            System.out.print("Localização: ");
            localizacao = scanner.nextLine().trim();
            if (localizacao.isEmpty()) {
                System.out.println("Localização não pode ser vazia.");
            }
        } while (localizacao.isEmpty());

        return new ObrasDeArte(titulo, artista, anoDeCriacao, tipo, localizacao);
    }
}
