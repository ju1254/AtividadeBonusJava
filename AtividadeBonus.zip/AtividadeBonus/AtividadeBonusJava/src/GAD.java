package gerenciamento;

import modelo.ObraDeArte;
import java.util.List;
import java.util.stream.Collectors;

public class GAD {
    private ObrasNoSistema ObrasNoSistema;

    public GerenciamentoObras(ObrasNoSistema ObrasNoSistema) {
        this.ObrasNoSistema = ObrasNoSistema;
    }

    public List<ObrasDeArte> buscarObrasPorArtista(String artista) {
        return ObrasNoSistema.listarTodasAsObras().stream()
                .filter(obra -> obra.getArtista().equalsIgnoreCase(artista))
                .collect(Collectors.toList());
    }

    public List<ObrasDeArte> buscarObrasPorAno(int ano) {
        return ObrasNoSistema.listarTodasAsObras().stream()
                .filter(obra -> obra.getAnoDeCriacao() == ano)
                .collect(Collectors.toList());
    }

    public List<ObrasDeArte> buscarObrasPorTipo(String tipo) {
        return ObrasNoSistema.listarTodasAsObras().stream()
                .filter(obra -> obra.getTipo().equalsIgnoreCase(tipo))
                .collect(Collectors.toList());
    }
}
