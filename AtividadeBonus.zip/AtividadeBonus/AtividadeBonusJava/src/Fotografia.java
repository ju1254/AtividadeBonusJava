package modelo;

public class Fotografia extends ObraDeArte {
    private String tecnicaFotografica;

    public Fotografia(String titulo, String artista, int anoDeCriacao, String tipo, String localizacao, String tecnicaFotografica) {
        super(titulo, artista, anoDeCriacao, tipo, localizacao);
        this.tecnicaFotografica = tecnicaFotografica;
    }

    public String getTecnicaFotografica() {
        return tecnicaFotografica;
    }

    public void setTecnicaFotografica(String tecnicaFotografica) {
        this.tecnicaFotografica = tecnicaFotografica;
    }

    @Override
    public String toString() {
        return super.toString() + ", TecnicaFotografica='" + tecnicaFotografica + '\'';
    }
}
public class Fotografia {

}
