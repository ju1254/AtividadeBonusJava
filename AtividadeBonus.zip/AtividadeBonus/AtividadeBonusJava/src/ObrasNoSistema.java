package gerenciamento;

import modelo.ObraDeArte;
import java.util.ArrayList;
import java.util.List;

public class ObrasNoSistema {
    private List<ObrasDeArte> obras;

    public ObrasNoSistema() {
        this.obras = new ArrayList<>();
    }

    public void adicionarObra(ObraDeArte obra) {
        obras.add(obra);
        System.out.println("Obra de arte adicionada com sucesso: " + obra.getTitulo());
    }

    public List<ObrasDeArte> buscarObraPorTitulo(String titulo) {
        List<ObrasDeArte> resultados = new ArrayList<>();
        for (ObrasDeArte obra : obras) {
            if (obra.getTitulo().equalsIgnoreCase(titulo)) {
                resultados.add(obra);
            }
        }
        return resultados;
    }

    public List<ObrasDeArte> listarTodasAsObras() {
        return new ArrayList<>(obras);
    }
}
