package principal;
import entrada.OrgModularSis;
import gerenciamento.ObrasNoSistema;
import gerenciamento.GAD;
import modelo.ObraDeArte;
import persistencia.FileManager;

import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ObrasNoSistema ObrasNoSistema = new ObrasNoSistema();
        GAD GAD = new GAD(ObrasNoSistema);

        List<ObrasDeArte> obrasSalvas = FileManager.carregarObras();
        for (ObraDeArte obra : obrasSalvas) {
            ObrasNoSistema.adicionarObra(obra);
        }

        boolean continuar = true;

        while (continuar) {
            System.out.println("---MUSEUM---");
            System.out.println("Escolha uma opção:");
            System.out.println("1. Cadastrar nova obra de arte");
            System.out.println("2. Buscar obra de arte por título");
            System.out.println("3. Listar todas as obras de arte");
            System.out.println("4. Atualizar obra de arte");
            System.out.println("5. Excluir obra de arte");
            System.out.println("6. Buscar obras por artista");
            System.out.println("7. Buscar obras por ano");
            System.out.println("8. Buscar obras por tipo");
            System.out.println("9. Sair");
            int op = scanner.nextInt();
            scanner.nextLine();

            switch (op) {
                case 1:
                    ObrasDeArte novaObra = InputHandler.lerDadosObraDeArte(scanner);
                    ObrasNoSistema.adicionarObra(novaObra);
                    break;

                case 2:
                    System.out.print("Título da obra a buscar: ");
                    String tituloBusca = scanner.nextLine().trim();
                    List<ObrasDeArte> obrasEncontradas = museu.buscarObraPorTitulo(tituloBusca);
                    if (obrasEncontradas.isEmpty()) {
                        System.out.println("Nenhuma obra encontrada com o título: " + tituloBusca);
                    } else {
                        System.out.println("Obras encontradas:");
                        for (ObraDeArte obra : obrasEncontradas) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 3:
                    List<ObrasDeArte> todasAsObras = museu.listarTodasAsObras();
                    if (todasAsObras.isEmpty()) {
                        System.out.println("Nenhuma obra cadastrada.");
                    } else {
                        System.out.println("Todas as obras cadastradas:");
                        for (ObrasDeArte obra : todasAsObras) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 4:
                    System.out.print("Título da obra a atualizar: ");
                    String tituloAtualizar = scanner.nextLine().trim();
                    ObrasDeArte obraAtualizada = InputHandler.lerDadosObraDeArte(scanner);
                    GAD.atualizarObra(tituloAtualizar, obraAtualizada);
                    break;

                case 5:
                    System.out.print("Título da obra a excluir: ");
                    String tituloExcluir = scanner.nextLine().trim();
                    GAD.removerObra(tituloExcluir);
                    break;

                case 6:
                    System.out.print("Artista das obras a buscar: ");
                    String artistaBusca = scanner.nextLine().trim();
                    List<ObrasDeArte> obrasPorArtista = GAD.buscarObrasPorArtista(artistaBusca);
                    if (obrasPorArtista.isEmpty()) {
                        System.out.println("Nenhuma obra encontrada para o artista: " + artistaBusca);
                    } else {
                        System.out.println("Obras encontradas:");
                        for (ObrasDeArte obra : obrasPorArtista) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 7:
                    System.out.print("Ano das obras a buscar: ");
                    int anoBusca = scanner.nextInt();
                    scanner.nextLine(); 
                    List<ObrasDeArte> obrasPorAno = obrasManager.buscarObrasPorAno(anoBusca);
                    if (obrasPorAno.isEmpty()) {
                        System.out.println("Nenhuma obra encontrada para o ano: " + anoBusca);
                    } else {
                        System.out.println("Obras encontradas:");
                        for (ObrasDeArte obra : obrasPorAno) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 8:
                    System.out.print("Tipo das obras a buscar: ");
                    String tipoBusca = scanner.nextLine().trim();
                    List<ObrasDeArte> obrasPorTipo = obrasManager.buscarObrasPorTipo(tipoBusca);
                    if (obrasPorTipo.isEmpty()) {
                        System.out.println("Nenhuma obra encontrada para o tipo: " + tipoBusca);
                    } else {
                        System.out.println("Obras encontradas:");
                        for (ObrasDeArte obra : obrasPorTipo) {
                            System.out.println(obra);
                        }
                    }
                    break;

                case 9:
                    continuar = false;
                    break;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }

            FileManager.salvarObras(museu.listarTodasAsObras());
        }

        scanner.close();
    }
}

