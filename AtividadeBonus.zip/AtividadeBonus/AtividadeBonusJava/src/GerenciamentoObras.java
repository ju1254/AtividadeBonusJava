//package management;
import modelo.ObraDeArte;
import java.util.List;

public class GerenciamentoObras {
    private ObrasNoSistema ObrasNoSistema;

    public GerenciamentoObras(ObrasNoSistema ObrasNoSistema) {
        this.ObrasNoSistema = ObrasNoSistema;
    }

    public void atualizarObra(String titulo, ObrasDeArte obraAtualizada) {
        List<ObrasDeArte> obras = ObrasNoSistema.buscarObraPorTitulo(titulo);
        if (obras.isEmpty()) {
            System.out.println("Obra não encontrada.");
        } else {
            for (ObrasDeArte obra : obras) {
                ObrasNoSistema.removerObra(obra);
                ObrasNoSistema.adicionarObra(obraAtualizada);
                System.out.println("Obra atualizada com sucesso.");
            }
        }
    }

    public void removerObra(String titulo) {
        List<ObrasDeArte> obras = ObrasNoSistema.buscarObraPorTitulo(titulo);
        if (obras.isEmpty()) {
            System.out.println("Obra não encontrada.");
        } else {
            for (ObrasDeArte obra : obras) {
                ObrasNoSistema.removerObra(obra);
                System.out.println("Obra removida com sucesso.");
            }
        }
    }
}

