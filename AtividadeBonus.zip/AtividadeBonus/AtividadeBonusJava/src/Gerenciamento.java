package persistencia;

import modelo.ObraDeArte;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Gerenciamento {
    private static final String FILE_PATH = "obras_de_arte.dat";

    public static void salvarObras(List<ObrasDeArte> obras) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(obras);
            System.out.println("Dados salvos com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public static List<ObrasDeArte> carregarObras() {
        List<ObraDeArte> obras = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            obras = (List<ObraDeArte>) ois.readObject();
            System.out.println("Dados carregados com sucesso.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return obras;
    }
}

